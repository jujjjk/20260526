from __future__ import annotations

from collections.abc import Sequence

import torch

from isaaclab.utils import configclass

from .cpg_cfg import CPGCfg
from .cpg_generator import QuadrupedCPG
from .deploy_actions import DeployFilteredJointPositionAction, DeployFilteredJointPositionActionCfg


class CPGFilteredJointPositionAction(DeployFilteredJointPositionAction):
    """Joint-position action term with optional CPG-only/residual target generation."""

    cfg: CPGFilteredJointPositionActionCfg

    def __init__(self, cfg: "CPGFilteredJointPositionActionCfg", env):
        super().__init__(cfg, env)
        self.cpg_cfg = cfg.cpg_cfg if cfg.cpg_cfg is not None else CPGCfg()
        limits = None
        if hasattr(self._asset.data, "joint_pos_limits") and self._asset.data.joint_pos_limits is not None:
            joint_limits = self._asset.data.joint_pos_limits[:, self._joint_ids]
            limits = (joint_limits[:, :, 0], joint_limits[:, :, 1])
        self._cpg = QuadrupedCPG(
            cfg=self.cpg_cfg,
            device=self.device,
            num_envs=self.num_envs,
            dt=float(self._env.step_dt),
            default_joint_pos=self._asset.data.default_joint_pos[:, self._joint_ids],
            joint_limits=limits,
        )
        self.last_q_cpg = torch.zeros_like(self.processed_actions)
        self.last_delta_q_rl = torch.zeros_like(self.processed_actions)
        self.last_clipped_actions = torch.zeros_like(self.processed_actions)
        self.last_q_raw_cpg = torch.zeros_like(self.processed_actions)
        self.last_clip_count = torch.zeros(self.num_envs, device=self.device)

    @property
    def cpg(self) -> QuadrupedCPG:
        return self._cpg

    def _commands(self) -> torch.Tensor:
        try:
            return self._env.command_manager.get_command(self.cfg.command_name)
        except Exception:
            return torch.zeros(self.num_envs, 3, device=self.device)

    def process_actions(self, actions: torch.Tensor):
        mode = self.cfg.action_mode
        if not bool(self.cpg_cfg.enable) or mode == "pure_rl" or self.cpg_cfg.mode == "off":
            super().process_actions(actions)
            self.last_q_cpg[:] = self._offset if isinstance(self._offset, torch.Tensor) else 0.0
            self.last_delta_q_rl.zero_()
            self.last_clipped_actions[:] = torch.clamp(actions, -1.0, 1.0)
            self.last_q_raw_cpg[:] = self._deploy_q_raw
            self.last_clip_count[:] = torch.sum(torch.abs(actions) > 1.0, dim=1)
            return

        self._raw_actions[:] = actions
        clipped_actions = torch.clamp(actions, -1.0, 1.0)
        self.last_clipped_actions[:] = clipped_actions
        self.last_clip_count[:] = torch.sum(torch.abs(actions) > 1.0, dim=1)

        commands = self._commands()
        q_cpg = self._cpg.update(commands)
        residual_limit = self._cpg.residual_limits
        if mode == "cpg_only" or self.cpg_cfg.mode == "joint_sine":
            delta_q_rl = torch.zeros_like(clipped_actions)
        else:
            delta_q_rl = torch.clamp(clipped_actions * residual_limit, min=-residual_limit, max=residual_limit)

        q_raw = q_cpg + delta_q_rl
        if self.cfg.clip is not None:
            q_raw = torch.clamp(q_raw, min=self._clip[:, :, 0], max=self._clip[:, :, 1])

        self._processed_actions[:] = q_raw
        self._deploy_q_raw[:] = q_raw
        self.last_q_cpg[:] = q_cpg
        self.last_delta_q_rl[:] = delta_q_rl
        self.last_q_raw_cpg[:] = q_raw

        if not self.cfg.enable_deploy_target_filter:
            self.last_q_cmd[:] = self.processed_actions
            self.last_qdot_cmd.zero_()
            return

        # Reuse the deploy-like limiter from the parent class, but start from
        # the CPG/residual q_raw target instead of affine action scaling.
        q_current = self._asset.data.joint_pos[:, self._joint_ids]
        uninit = ~self._initialized
        if torch.any(uninit):
            self._q_last_cmd[uninit] = q_current[uninit]
            self._qdot_last_cmd[uninit] = 0.0
            self._delay_buffer[uninit] = q_current[uninit].unsqueeze(1)
            self._initialized[uninit] = True

        dt = float(self._env.step_dt)
        kp_eff = max(float(self.cfg.sim_kp), 1.0e-6) * self._kp_scale * self._motor_strength
        err_limit = (self._torque_budget / kp_eff) * self._err_limit_mul
        damping_scale = torch.sqrt(torch.clamp(self._kd_scale, min=0.5, max=2.0))
        rate_limit = (self._target_rate_limit / damping_scale) * self._target_rate_mul
        accel_limit = (self._target_accel_limit / damping_scale) * self._target_accel_mul

        q_safe = q_current + torch.clamp(q_raw - q_current, min=-err_limit, max=err_limit)
        qdot_raw = torch.clamp((q_safe - self._q_last_cmd) / dt, min=-rate_limit, max=rate_limit)
        qdot_delta = torch.clamp(qdot_raw - self._qdot_last_cmd, min=-accel_limit * dt, max=accel_limit * dt)
        qdot_cmd = self._qdot_last_cmd + qdot_delta
        q_cmd = self._q_last_cmd + qdot_cmd * dt
        q_cmd = q_current + torch.clamp(q_cmd - q_current, min=-err_limit, max=err_limit)

        self._q_last_cmd[:] = q_cmd
        self._qdot_last_cmd[:] = qdot_cmd
        self.last_q_cmd[:] = q_cmd
        self.last_qdot_cmd[:] = qdot_cmd

        self._delay_buffer = torch.roll(self._delay_buffer, shifts=1, dims=1)
        self._delay_buffer[:, 0] = q_cmd
        delay_idx = torch.clamp(self._motor_delay_steps.squeeze(-1) - 1, min=0, max=self._delay_buffer.shape[1] - 1)
        self._processed_actions = self._delay_buffer[torch.arange(self.num_envs, device=self.device), delay_idx]

    def reset(self, env_ids: Sequence[int] | None = None) -> None:
        super().reset(env_ids)
        if env_ids is None:
            env_ids_tensor = torch.arange(self.num_envs, device=self.device)
        else:
            env_ids_tensor = torch.as_tensor(env_ids, device=self.device, dtype=torch.long)
        self._cpg.reset(env_ids_tensor)
        self.last_q_cpg[env_ids_tensor] = self._asset.data.default_joint_pos[env_ids_tensor][:, self._joint_ids]
        self.last_delta_q_rl[env_ids_tensor] = 0.0


@configclass
class CPGFilteredJointPositionActionCfg(DeployFilteredJointPositionActionCfg):
    """Deploy-like joint target filter with optional CPG residual target generation."""

    class_type: type = CPGFilteredJointPositionAction
    action_mode: str = "cpg_residual"  # pure_rl, cpg_only, cpg_residual
    command_name: str = "base_velocity"
    cpg_cfg: CPGCfg | None = CPGCfg()
