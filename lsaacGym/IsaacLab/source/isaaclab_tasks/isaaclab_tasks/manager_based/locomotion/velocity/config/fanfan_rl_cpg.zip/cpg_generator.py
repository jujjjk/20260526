from __future__ import annotations

import math
from typing import Any

import torch

from .cpg_cfg import CPGCfg


class QuadrupedCPG:
    """Small, vectorized CPG for Fanfan joint-space residual training."""

    def __init__(
        self,
        cfg: CPGCfg,
        device: str | torch.device,
        num_envs: int,
        dt: float,
        default_joint_pos: torch.Tensor,
        joint_limits: tuple[torch.Tensor, torch.Tensor] | None = None,
        urdf_params: dict[str, Any] | None = None,
        motor_profile: dict[str, Any] | None = None,
    ) -> None:
        self.cfg = cfg
        self.device = torch.device(device)
        self.num_envs = int(num_envs)
        self.dt = float(dt)
        self.default_joint_pos = default_joint_pos.to(self.device).clone()
        if self.default_joint_pos.ndim == 1:
            self.default_joint_pos = self.default_joint_pos.unsqueeze(0).repeat(self.num_envs, 1)
        self.joint_limits = joint_limits
        self.urdf_params = urdf_params or {}
        self.motor_profile = motor_profile or {}

        self.base_phase = torch.zeros(self.num_envs, device=self.device)
        self.last_frequency = torch.zeros(self.num_envs, device=self.device)
        self.last_step_length = torch.zeros(self.num_envs, device=self.device)
        self.last_step_height = torch.full((self.num_envs,), float(cfg.step_height), device=self.device)
        self.last_leg_phase = torch.zeros(self.num_envs, len(cfg.leg_order), device=self.device)
        self.last_q_cpg = self.default_joint_pos.clone()

        self._residual_limits = self._make_joint_type_tensor(
            hip=float(cfg.residual_limit_hip),
            thigh=float(cfg.residual_limit_thigh),
            calf=float(cfg.residual_limit_calf),
            fallback=float(cfg.residual_limit),
        )
        self._joint_signs = torch.tensor(cfg.joint_signs, device=self.device, dtype=self.default_joint_pos.dtype).view(
            1, -1
        )
        self._joint_offsets = torch.tensor(
            cfg.joint_offsets, device=self.device, dtype=self.default_joint_pos.dtype
        ).view(1, -1)

    @property
    def residual_limits(self) -> torch.Tensor:
        return self._residual_limits

    def _make_joint_type_tensor(self, hip: float, thigh: float, calf: float, fallback: float) -> torch.Tensor:
        values = []
        for name in self.cfg.joint_order:
            if "hip" in name:
                values.append(hip)
            elif "thigh" in name:
                values.append(thigh)
            elif "calf" in name or "knee" in name:
                values.append(calf)
            else:
                values.append(fallback)
        return torch.tensor(values, device=self.device, dtype=self.default_joint_pos.dtype).view(1, -1)

    def reset(self, env_ids: torch.Tensor | list[int] | None = None) -> None:
        if env_ids is None:
            env_ids_tensor = torch.arange(self.num_envs, device=self.device)
        else:
            env_ids_tensor = torch.as_tensor(env_ids, dtype=torch.long, device=self.device)
        if bool(self.cfg.initial_phase_random):
            self.base_phase[env_ids_tensor] = torch.rand(env_ids_tensor.numel(), device=self.device) * (2.0 * math.pi)
        else:
            self.base_phase[env_ids_tensor] = 0.0
        self.last_q_cpg[env_ids_tensor] = self.default_joint_pos[env_ids_tensor]

    def compute_frequency(self, commands: torch.Tensor) -> torch.Tensor:
        cmd_x = torch.abs(commands[:, 0])
        standing = cmd_x < float(self.cfg.standing_cmd_threshold)
        if self.cfg.freq_mode == "velocity_step_length":
            step_length = torch.clamp(
                float(self.cfg.k_step) * cmd_x,
                min=float(self.cfg.step_length_min),
                max=float(self.cfg.step_length_max),
            )
            freq = cmd_x / torch.clamp(step_length, min=1.0e-5)
        else:
            step_length = torch.clamp(
                float(self.cfg.k_step) * cmd_x,
                min=float(self.cfg.step_length_min),
                max=float(self.cfg.step_length_max),
            )
            freq = float(self.cfg.freq_min) + float(self.cfg.k_freq) * cmd_x
        freq = torch.clamp(freq, min=float(self.cfg.freq_min), max=float(self.cfg.freq_max))
        freq = torch.where(standing, torch.zeros_like(freq), freq)
        self.last_frequency = freq
        self.last_step_length = torch.where(standing, torch.zeros_like(step_length), step_length)
        return freq

    def compute_phase(self, commands: torch.Tensor) -> torch.Tensor:
        frequency = self.compute_frequency(commands)
        self.base_phase = torch.remainder(self.base_phase + 2.0 * math.pi * frequency * self.dt, 2.0 * math.pi)
        offsets = self.cfg.phase_offsets.get(self.cfg.gait, self.cfg.phase_offsets["trot"])
        phase_cols = []
        for leg in self.cfg.leg_order:
            phase_cols.append(torch.remainder(self.base_phase + 2.0 * math.pi * float(offsets[leg]), 2.0 * math.pi))
        self.last_leg_phase = torch.stack(phase_cols, dim=1)
        return self.last_leg_phase

    def compute_joint_sine(self, leg_phase: torch.Tensor) -> torch.Tensor:
        q = self.default_joint_pos.clone()
        hip_amp = float(self.cfg.joint_sine.hip_amp)
        thigh_amp = float(self.cfg.joint_sine.thigh_amp)
        calf_amp = float(self.cfg.joint_sine.calf_amp)
        thigh_shift = float(self.cfg.joint_sine.thigh_phase_shift) * 2.0 * math.pi
        calf_shift = float(self.cfg.joint_sine.calf_phase_shift) * 2.0 * math.pi
        moving = (self.last_frequency > 0.0).to(q.dtype).unsqueeze(1)

        for leg_i, leg in enumerate(self.cfg.leg_order):
            base = leg_i * 3
            phase = leg_phase[:, leg_i]
            side = -1.0 if leg in ("FR", "RR") else 1.0
            q[:, base + 0] += moving[:, 0] * side * hip_amp * torch.sin(phase)
            q[:, base + 1] += moving[:, 0] * thigh_amp * torch.sin(phase + thigh_shift)
            q[:, base + 2] += moving[:, 0] * calf_amp * torch.sin(phase + calf_shift)
        q = q * self._joint_signs + self._joint_offsets
        return self._clip_to_limits(q)

    def compute_foot_trajectory(self, leg_phase: torch.Tensor, commands: torch.Tensor) -> torch.Tensor:
        phase01 = torch.remainder(leg_phase / (2.0 * math.pi), 1.0)
        duty = float(self.cfg.duty_factor)
        step = self.last_step_length.unsqueeze(1)
        z = torch.zeros_like(phase01)
        x = torch.zeros_like(phase01)
        swing = phase01 >= duty
        s_swing = torch.clamp((phase01 - duty) / max(1.0 - duty, 1.0e-5), 0.0, 1.0)
        s_stance = torch.clamp(phase01 / max(duty, 1.0e-5), 0.0, 1.0)
        x = torch.where(swing, -0.5 * step + step * s_swing, 0.5 * step - step * s_stance)
        z = torch.where(swing, float(self.cfg.step_height) * torch.sin(math.pi * s_swing), z)
        y = torch.zeros_like(x)
        return torch.stack((x, y, z), dim=-1)

    def inverse_kinematics(self, foot_pos: torch.Tensor) -> torch.Tensor:
        # Conservative placeholder for v1.  Keep foot_ik mode executable while
        # avoiding unverified sign/axis assumptions on hardware.
        q = self.default_joint_pos.clone()
        q[:, 1::3] += torch.clamp(foot_pos[:, :, 0], -0.04, 0.04).reshape(self.num_envs, 4)
        q[:, 2::3] -= torch.clamp(foot_pos[:, :, 2], 0.0, 0.04).reshape(self.num_envs, 4)
        return self._clip_to_limits(q)

    def update(self, commands: torch.Tensor, obs: torch.Tensor | None = None) -> torch.Tensor:
        leg_phase = self.compute_phase(commands)
        if self.cfg.mode == "foot_ik":
            foot_pos = self.compute_foot_trajectory(leg_phase, commands)
            q_cpg = self.inverse_kinematics(foot_pos)
        else:
            q_cpg = self.compute_joint_sine(leg_phase)
        self.last_q_cpg = q_cpg
        return q_cpg

    def _clip_to_limits(self, q: torch.Tensor) -> torch.Tensor:
        if self.joint_limits is None or not bool(self.cfg.filter.use_joint_limit_clip):
            return q
        lower, upper = self.joint_limits
        return torch.clamp(q, lower.to(q.device), upper.to(q.device))
